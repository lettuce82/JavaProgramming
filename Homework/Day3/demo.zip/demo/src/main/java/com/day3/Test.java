package com.day3;

public class Test {
    
    public static void main(String[] args) {
        Mart mart = new Mart();
        mart.start();
    }
}
