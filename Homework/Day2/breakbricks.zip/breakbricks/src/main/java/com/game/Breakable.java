package com.game;

public interface Breakable {
    boolean isBroken(MovableBall other);
}
