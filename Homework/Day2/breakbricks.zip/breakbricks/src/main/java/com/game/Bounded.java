package com.game;

public interface Bounded {
    public void bounce(Regionable other);
    boolean isOutOfBounds();
}
