package com.game;

public class Main {
    public static void main(String[] args) {
        BreakBricks.Start();
    }
}
