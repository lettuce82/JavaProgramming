package com.example.interfaces;

public interface Brittle {
}