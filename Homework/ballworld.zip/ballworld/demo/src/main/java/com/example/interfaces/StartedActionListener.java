package com.example.interfaces;

public interface StartedActionListener {
    public void action();
}
