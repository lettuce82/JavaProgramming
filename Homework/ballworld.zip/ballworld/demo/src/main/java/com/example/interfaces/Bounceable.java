package com.example.interfaces;

public interface Bounceable {
    public void bounce(Bounded other);
}
