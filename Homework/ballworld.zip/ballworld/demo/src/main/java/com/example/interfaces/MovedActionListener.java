package com.example.interfaces;

public interface MovedActionListener {
    public void action();
}
