package com.example.interfaces;

public interface HitInterface {
    default void hit(Bounded ball) {
    }
    
}
