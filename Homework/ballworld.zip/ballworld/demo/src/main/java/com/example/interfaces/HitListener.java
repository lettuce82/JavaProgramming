package com.example.interfaces;

public interface HitListener {
    void hit(Bounded other);
}
